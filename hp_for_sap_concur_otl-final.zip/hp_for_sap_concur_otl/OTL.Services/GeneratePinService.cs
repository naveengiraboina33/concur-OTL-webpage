using System;
using OtpNet;
using OTL.Repository.Models;
using OTL.Services.Interfaces;
using OTL.Repository.Interfaces;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;

namespace OTL.Services
{
    public class GeneratePinService : IGeneratePinService
    {
        private const int _iterationCounts = 10000;
        private const int _bytesRequested = 32;
        private const int _bytes = 16;
        private IUserRepository _userRepository;
        public GeneratePinService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }
        public int SaveConcurDetails(UserDetails userDetails)
        {
            try
            {
                return _userRepository.SaveConcurDetails(userDetails);
            }
            catch (Exception ex)
            {
                var error = ex.InnerException.Message;
                return 0;
            }
        }

        //To generate the PIN
        public string GeneratePIN()
        {
            try
            {
                Random random = new Random();
                var secretKey = new byte[random.Next()];
                var pinCode = new Totp(secretKey, mode: OtpHashMode.Sha256);

                var pin = pinCode.ComputeTotp();
                return pin;
            }
            catch (Exception ex)
            {
                var error = ex.InnerException.Message;
                return "Error while generating the PIN";
            }
        }

        //To hash the PIN
        public UserDetails HashPIN(string pin)
        {
            try
            {
                UserDetails hash = new UserDetails();
                byte[] salt = new byte[_bytes];
                using (var rng = RandomNumberGenerator.Create())
                {
                    rng.GetBytes(salt);
                }

                string hashedPin = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                    password: pin,
                    salt: salt,
                    prf: KeyDerivationPrf.HMACSHA256,
                    iterationCount: _iterationCounts,
                    numBytesRequested: _bytesRequested));

                hash.Salt = Convert.ToBase64String(salt);
                hash.Hashed_Pin = hashedPin;
                return hash;
            }
            catch (Exception ex)
            {
                var error = ex.InnerException.Message;
                return null;
            }
        }
    }
}