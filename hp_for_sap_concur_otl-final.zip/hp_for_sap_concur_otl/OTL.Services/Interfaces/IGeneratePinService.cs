﻿using OTL.Repository.Models;

namespace OTL.Services.Interfaces
{
    public interface IGeneratePinService
    {
        string GeneratePIN();
        UserDetails HashPIN(string pin);
        int SaveConcurDetails(UserDetails redirectRequest);
    }
}
