using OTL.Repository.Models;

namespace OTL.Repository.Interfaces
{
    public interface IUserRepository
    {      
        int SaveConcurDetails(UserDetails userDetails);        
    }
}