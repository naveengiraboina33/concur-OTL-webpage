using System;
using OTL.Repository.Models;
using OTL.Repository.Interfaces;

namespace OTL.Repository
{
    public class UserRepository : IUserRepository
    {
        private UserDetailsContext _userDetailsContext;
        public UserRepository(UserDetailsContext context)
        {
            _userDetailsContext = context;
        }

        //To save Concur details in Database
        public int SaveConcurDetails(UserDetails userDetails)
        {
            try
            {
                _userDetailsContext.Users.Add(userDetails);
                _userDetailsContext.SaveChanges();

                return Convert.ToInt32(userDetails.Id);
            }
            catch (Exception ex)
            {
                var error = ex.InnerException.Message;
                return 0;
            }
        }
    }
}