using Microsoft.EntityFrameworkCore;

namespace OTL.Repository.Models
{
    public static class DbInitializer
    {
        public static void Initialize(UserDetailsContext context){
            context.Database.Migrate();

            //Add Seed Data
        }
    }

}