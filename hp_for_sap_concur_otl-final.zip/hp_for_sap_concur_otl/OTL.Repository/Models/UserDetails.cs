using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OTL.Repository.Models
{
    public class UserDetails
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public string State { get; set; }
        public string Concur_AuthCode { get; set; }
        public string Geolocation { get; set; }
        public string Salt { get; set; }
        public string Hashed_Pin { get; set; }
        public string Concur_AccessToken { get; set; }
        public DateTime Timestamp { get; set; }
        public int NumberOfAttempts { get; set; }
    }
}
