
using Microsoft.EntityFrameworkCore;

namespace OTL.Repository.Models
{
    public class UserDetailsContext : DbContext
    {
        public UserDetailsContext(DbContextOptions options) : base(options)
        {            
        }

        public DbSet<UserDetails> Users { get; set; }
    }
}