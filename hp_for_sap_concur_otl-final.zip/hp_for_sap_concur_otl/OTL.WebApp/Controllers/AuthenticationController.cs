using System;
using System.Text;
using OTL.WebApp.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;

using Microsoft.Extensions.Configuration;

namespace OTL.WebApp.Controllers
{
    [Route("authenticate")]
    public class AuthenticationController : Controller
    {
        private IConfiguration _configuration;
        private string _clientId;
        private string _clientSecret;

        public AuthenticationController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost, Route("authenticate")]
        public IActionResult Authenticate([FromBody]ClientCredentials user)
        {
            if (user == null)
            {
                return BadRequest("Invalid request");
            }

            _clientId = _configuration.GetValue<string>("Client_CredentialsId:Client_Id");
            _clientSecret = _configuration.GetValue<string>("Client_CredentialsSecret:Client_Secret");

            if (user.ClientId == _clientId && user.ClientSecret == _clientSecret)
            {
                var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("KeyForSignInSecret"));
                var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);

                var tokeOptions = new JwtSecurityToken(
                    issuer: "https://localhost:5001",
                    audience: "https://localhost:5001",
                    claims: new List<Claim>(),
                    expires: DateTime.Now.AddMinutes(15),
                    signingCredentials: signinCredentials
                );

                var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);
                return Ok(new { Token = tokenString });
            }
            else
            {
                return Unauthorized();
            }
        }
    }
}