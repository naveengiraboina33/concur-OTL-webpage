using OTL.WebApp.Models;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Authorization;

namespace OTL.WebApp.Controllers
{
    public class ErrorController : Controller
    {
        [Route("Error/{statuscode}")]
        public IActionResult HttpStatusCodeHandler(int statuscode)
        {
            switch (statuscode)
            {
                case 404:
                    ViewBag.ErrorMessage = "The requested resource was Not Found";
                    break;
                case 500:
                    ViewBag.ErrorMessage = "Internal server error while generating the PIN";
                    break;
                default:
                    ViewBag.ErrorMessage = "Error while generating the PIN";
                    break;
            }
            return View("Errors");
        }

        [Route("Error")]
        //[AllowAnonymous]
        public IActionResult Error()
        {
            var exceptionDetails = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            ViewBag.ExceptionPath = exceptionDetails.Path;
            ViewBag.ExceptionMessage = exceptionDetails.Error.Message;
            return View("Error");
        }
    }
}
