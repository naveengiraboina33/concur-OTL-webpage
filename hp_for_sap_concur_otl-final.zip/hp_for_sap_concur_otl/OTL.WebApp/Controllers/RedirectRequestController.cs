using System;
using System.Net.Http;
using OTL.Repository.Models;
using System.Threading.Tasks;
using OTL.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;

namespace OTL.WebApp.Controllers
{
    public class RedirectRequestController : Controller
    {
        private IConfiguration _configuration;
        private IGeneratePinService _generatePinService;
        private IHttpClientFactory _httpClientFactory;

        public RedirectRequestController(IGeneratePinService generatePinService, IConfiguration configuration, IHttpClientFactory httpClientFactory)
        {
            _generatePinService = generatePinService;
            _configuration = configuration;
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> RedirectRequest(string State, string ConcurAuthCode, string Geolocation)
        {
            try
            {
                UserDetails userDetails = new UserDetails();
                var requestParams = new
                {
                    concurAuthCode = ConcurAuthCode,
                    clientId = _configuration.GetValue<string>("Client_CredentialsId:Client_Id"),
                    clientSecret = _configuration.GetValue<string>("Client_CredentialsSecret:Client_Secret"),
                    grant_Type = "authorization_code"
                };

                var tokenURL = _configuration.GetValue<string>("TokenURL:UrlValue");
                var client = _httpClientFactory.CreateClient();
                client.BaseAddress = new Uri("http://concursolutions.com");
                var response = await client.PostAsJsonAsync(tokenURL, requestParams);
                var token = response.Content.ReadAsStringAsync();
                //var token1 = "token";

                if (token != null)
                {
                    userDetails.State = State;
                    userDetails.Concur_AccessToken = Convert.ToString(token);
                    userDetails.Geolocation = Geolocation;
                    userDetails.Concur_AuthCode = ConcurAuthCode;

                    string pin = _generatePinService.GeneratePIN();
                    if (pin != null)
                    {
                        ViewData["PIN"] = pin;
                    }
                    else
                    {
                        Response.StatusCode = 500;
                        ViewData["ErrorMessage"] = "Error while generating the PIN";
                        return View("~/Views/Home/ErrorGeneratingPIN.cshtml");
                    }
                    var hashedPIN = _generatePinService.HashPIN(pin);
                    if (hashedPIN != null)
                    {
                        userDetails.Salt = hashedPIN.Salt;
                        userDetails.Hashed_Pin = hashedPIN.Hashed_Pin;
                        userDetails.Timestamp = DateTime.Now;
                        ViewData["DisplayTime"] = userDetails.Timestamp.AddMinutes(15).ToShortTimeString();
                        //TODO 
                        int id = _generatePinService.SaveConcurDetails(userDetails);
                        if (id == 0)
                        {
                            ViewData["ErrorMessage"] = "Error while inserting into the database";
                            return View("~/Views/Home/ErrorGeneratingPIN.cshtml");
                        }
                    }
                    else
                    {
                        Response.StatusCode = 500;
                        ViewData["ErrorMessage"] = "Internal server error";
                        return View("~/Views/Home/ErrorGeneratingPIN.cshtml");
                    }

                    return View("~/Views/RedirectRequest/DisplayPIN.cshtml");
                }
                else
                {
                    return View("~/Views/Home/ErrorGeneratingPIN.cshtml");
                }
            }
            catch (Exception e)
            {
                var error = e.InnerException.Message;
                ViewData["ErrorMessage"] = error;
                return View("~/Views/Home/ErrorGeneratingPIN.cshtml");
            }
        }
    }
}
