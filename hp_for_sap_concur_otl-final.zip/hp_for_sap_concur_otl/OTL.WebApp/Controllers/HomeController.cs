﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using OTL.WebApp.Models;

namespace OTL.WebApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {            
            return View();
        }
    }
}
